<?php include('../layout/header.php') ?>
<form action="" method="post">
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Tambah Course</h3>
        </div>
        <div class="card-body">
            <div class="mb-3">
                <label for="" class="form-label">Mentor</label>
                <select name="mentor_id" class="form-control">
                    <option value="">-- Pilih Mentor --</option>
                    <?php
                      $mentor = null;
                      $getAllMentorSql = "select id, fullname from users where role = 'mentor' and deleted_at is null";
                      $res = mysqli_query($conn, $getAllMentorSql);
                      if ($res) {
                        $mentor = mysqli_fetch_all($res, MYSQLI_ASSOC);
                      }
                    ?>
                    <?php if($mentor != null): ?>
                        <?php foreach($mentor as $val): ?>
                            <option value="<?php echo $val->id; ?>"><?php echo $val->fullname ?></option>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="" class="form-label">Name Course</label>
                <input type="text" name="name" class="form-control">
            </div>
        </div>
        <div class="card-footer">
            <a href="<?php echo SITEURL; ?>admin/manage-course.php" class="btn btn-secondary me-3">Kembali</a>
            <button type="submit" class="btn btn-primary" name="submit">Submit</button>
        </div>
    </div>
</form>
<?php
if(isset($_POST['submit'])){
    $mentor = mysqli_real_escape_string($conn, $_POST['mentor_id']);
    $nameCourse = mysqli_real_escape_string($conn, $_POST['name']);
    $checkCourseSql = "select * from course where name = '$nameCourse'";
    $resultCheckCourse = mysqli_query($conn, $checkCourseSql);
    if ($resultCheckCourse) {
        $countResultCheckCourse = mysqli_num_rows($resultCheckCourse);
        if ($countResultCheckCourse > 0) {
            echo "nama course sudah ada";
            exit;
        }
    }

    $insertCourseSql = "";


}
?>
<?php include('../layout/footer.php') ?>