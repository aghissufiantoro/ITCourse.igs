<?php include('../layout/header.php') ?>
<div>ini dashboard admin</div>
<?php include('../layout/footer.php') ?>