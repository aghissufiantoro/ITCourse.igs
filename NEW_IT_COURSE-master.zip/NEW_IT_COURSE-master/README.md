# IT_COURSE

## HOW TO USE
```bash
- clone this project
- copy constants.php.example to constants.php in inside folder config
- customize DB_USERNAME untill DB_NAME with your own configuration 
```