<?php include('../layout/header.php') ?>
<div>ini dashboard user</div>
<?php include('../layout/footer.php') ?>